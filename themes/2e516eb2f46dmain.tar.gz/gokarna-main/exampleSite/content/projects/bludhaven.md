---
title: Blüdhaven
type: page
---

### History

Blüdhaven was a former whaling town, which was officially incorporated as a "Commonwealth" in 1912. The town had a generally poor socio-economic populace, owing in part to failed efforts to transform itself into a manufacturing and shipping center.
